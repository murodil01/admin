import LeadSide from "../../components/lead-parts/leads-side";

function Leads() {
  return (
    <div>
      <LeadSide />
    </div>
  );
}

export default Leads;